import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';

final btnColor = Color(0xff2F8C86);
final bgColor = Color(0xff070F15);
final teal = Colors.teal;
final colorWhite = Colors.white;
